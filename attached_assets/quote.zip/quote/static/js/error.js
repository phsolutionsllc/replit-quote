// Note: Declaring components in global scope for browser usage
const ErrorReporter = ({ onClose, quoteData }) => {
    const [issueType, setIssueType] = React.useState('');
    const [notes, setNotes] = React.useState('');
  
    const handleSubmit = async (e) => {
      e.preventDefault();
      
      try {
        const response = await fetch('/report-error', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            issueType,
            notes,
            quoteData
          }),
        });
  
        if (response.ok) {
          const snackbar = document.getElementById('snackbar');
          if (snackbar) {
            snackbar.textContent = 'Quoting error reported';
            snackbar.className = 'show';
            setTimeout(() => snackbar.classList.remove('show'), 2000);
          }
          onClose();
        }
      } catch (error) {
        console.error('Error submitting report:', error);
      }
    };
  
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl p-6 max-w-lg w-full mx-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Report Quote Issue</h2>
            <button 
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
              aria-label="Close modal"
            >
              ✕
            </button>
          </div>
  
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Issue Type
              </label>
              <select
                value={issueType}
                onChange={(e) => setIssueType(e.target.value)}
                className="w-full p-2 border rounded-md"
                required
              >
                <option value="">Select issue type</option>
                <option value="wrong_price">Wrong Price</option>
                <option value="underwriting_issue">Underwriting Issue</option>
                <option value="eapp_link">eApp Link Not Working</option>
                <option value="logo_issue">Logo Not Working</option>
                <option value="other">Other</option>
              </select>
            </div>
  
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Additional Notes
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full p-2 border rounded-md"
                rows="3"
                placeholder="Optional details about the issue..."
              />
            </div>
  
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
              >
                Submit Report
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };
  
  // Declare ErrorButton in global scope
  const ErrorButton = ({ quoteData }) => {
    const [showModal, setShowModal] = React.useState(false);
  
    return (
      <>
        <div
          className="inline-block cursor-pointer"
          onClick={() => setShowModal(true)}
          title="Report an issue with this quote"
        >
          🚨
        </div>
        {showModal && (
          <ErrorReporter
            onClose={() => setShowModal(false)}
            quoteData={quoteData}
          />
        )}
      </>
    );
  };
  
  // Make ErrorButton available globally
  window.ErrorButton = ErrorButton;